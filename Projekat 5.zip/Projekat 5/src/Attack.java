public interface Attack {
    int getEffectiveDamage();
}